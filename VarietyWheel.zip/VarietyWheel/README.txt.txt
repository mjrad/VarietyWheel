=-=-=-=-=-=-= Variety Wheel v1.0 =-=-=-=-=-=-=
       - created by Mitchell Radford - 
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=

=-=-=-=-=-=-=-=-=-=-=-=-=-=
   CREATING A COLLECTION      
=-=-=-=-=-=-=-=-=-=-=-=-=-=

* Collections can be created by simply having a folder in "./icons". A folder named
   "My collection" will  display as "My collection" in the dropdown.

* Adding a new collection requires a restart on the app.

=-=-=-=-=-=-=-=-=-=-=-=-=-=
      IMAGE IMPORTING      
=-=-=-=-=-=-=-=-=-=-=-=-=-=

1) The image must be a .PNG or a .JPG. They must be 800x800px to render properly.

2) Put your image into a collection folder (./icons/FOLDER>/). You can access the folder quickly with
   the IMAGE button in the top right of the app.

3) Reload that collection in the app by selecting the corresponding number in the top-right.


=-=-=-=-=-=-=-=-=-=-=-=-=-=
      SOUND IMPORTING      
=-=-=-=-=-=-=-=-=-=-=-=-=-=

* There are 3 sounds.
  - "music.mp3": general background music
  - "spin.mp3": sound to play when the wheel spins
  - "win.mp3": wheel stopping fanfare

1) The image must be a .MP3

2) Put your sound files in the sound folder (./sounds). You can access the folder quickly with
   the IMAGE button in the top right of the app and going up a directory.

3) Restart the app.


=-=-=-=-=-=-=-=-=-=-=-=-=-=
    BACKGROUND IMPORTING      
=-=-=-=-=-=-=-=-=-=-=-=-=-=

1) The image must be "pattern.png". It must be 128x128px to work correctly.

2) Place the image in the background folder (./background). You can access the
   folder quickly with the IMAGE button in the top right of the app and going up a directory.

3) Restart the app.


=-=-=-=-=-=-=-=-=-=-=-=-=-=
        WHEEL CONFIG      
=-=-=-=-=-=-=-=-=-=-=-=-=-=

1) To edit what is shown on the wheel, select the SETTINGS button in the top right.

2) Click an icon in the popup to toggle it on the wheel. RED is inactive, GREEN is active.